create PROCEDURE "GETDATASETPACKAGERCOUNT"(taskid in  varchar2, --任务ID
                                                      countx  out number)
--应用流程模板获取数据集规则数量
 AS
     allcount number; --任务下数据总量
     numcounts varchar2(4000); --获取数据集最大的数字 可能是其他字符
     isnum varchar2(4000);
     vmtask varchar2(50);
begin
      vmtask :=taskid;
     select count(*) into allcount
            from pm_data_object d, pm_structure_relation r
           where d.id = r.childid
             and r.parentid =vmtask;

             select substr(max(name), length('数据集') + 1) into  numcounts
                       from pm_data_object d, pm_structure_relation r
                      where d.id = r.childid
                        and r.parentid = vmtask
                        and d.modelid = 'DataSetPackage'
                        and name like '数据集%';


   select decode(replace(translate(numcounts,'0123456789.',' '),' ',''),null, 'true','false')
   into isnum  from dual;

  case  when allcount=0
     then select 0 into countx from dual;
   else
        case when isnum='true' then
          case when to_number(numcounts)=0
            then select allcount into countx from dual;
          else
           select to_number(numcounts) into countx from dual;
            end case;
       else select allcount into countx from dual;
        end case ;
   end case ;


   END;
/

