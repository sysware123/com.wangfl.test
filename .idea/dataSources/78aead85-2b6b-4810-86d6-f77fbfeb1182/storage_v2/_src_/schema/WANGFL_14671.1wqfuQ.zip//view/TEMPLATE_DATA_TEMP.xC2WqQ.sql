create view TEMPLATE_DATA_TEMP as
  select t."ID",t."MODELTYPEID",t."MODELID",t."NAME",t."CREATORID",t."CREATETIME",t."UPDATERID",t."UPDATETIME",t."SECURITYDEGREEID",t."STATUSID",t."DESCRIPTION",t."ROWSTATUSID",t."REVISION",t."CHANGED",t."VERSIONNAME",t."BOOLEANVALUE",t."DATEVALUE",t."DOUBLEVALUE",t."STRINGVALUE",t."INTVALUE",t."UNITID",t."TASKID",t."FILEVALUE",t."PROJECTPHASEID",t."DISCIPLINE",t."CHARGEDEPARTMENTID",t."CODE",t."IMPORT_FLAG",t."TEMPLATECODE",t."DEPARTMENTTYPE",t."ARRAYLENGTH",t."DIMENSION",t."RELATIVEPATH",t."OUTERSYSTYPE",t."OUTERSYSID",t."DEFAULTSET",t."URLVALUE",t."ACCEPTSPECIALTYID",
	       t."IMPORT_FLAG" importFlag, --特殊的处理
	       case
	         when t.filevalue is not null then
	          '' || f.filename
	         when t.STRINGVALUE is not null then
	          t.STRINGVALUE
	        when t.urlVALUE is not null then
	          t.urlVALUE
	         when t.datevalue is not null then
	          to_char(t.datevalue, 'yyyy-mm-dd hh24:mi:ss')
	         when t.booleanvalue is not null then
	          '' || t.booleanvalue
	         when t.doublevalue is not null then
	          to_char(t.doublevalue, '99999999999990.999999')
	         when t.INTVALUE is not null then
	          '' || t.INTVALUE
	       end as value, -- 值，value属性统一为字符串
	       r."RELATIONID",
	       r."RELATIONTYPE",
	       r."PARENTMODELTYPEID",
	       r."PARENTMODELID",
	       r."PARENTID",
	       r."CHILDMODELTYPEID",
	       r."CHILDMODELID",
	       r."CHILDID",
	       r."SORTORDER",
	       r."WBSCODE",
	       r."TREEPATH",
	       r."REVISION" relationRevision,
	       r."ROWSTATUSID" relationRowStatusId,
	       r."REFID",
	       r."REFREVISION",
	       r."REFTYPE",
	       r."REFEDITABLE",
	       status.status_name statusName, --数据状态
	       parent.name parentName, --父名称
	       task.name taskName, --任务名称
	       du.unit_name unitName, -- 单位名称
	       (select count(*)
	          from dm_dt_structure_relation r
	         where r.parentid = t.id
	           and r.relationtype = 'relation') as relationLeafCount --子节点数量，包含活动数据流程数据类型
	       ,
	       (select count(*)
	          from dm_dt_structure_relation r
	         where r.parentid = t.id
	           and r.relationtype = 'data') as dataLeafCount --子节点数量，数据模板
	  from dm_dt_data_object t
	  left join dm_dt_structure_relation r
	    on t.id = r.childid
	  left join dm_dt_data_object parent
	    on parent.id = r.parentid
	  left join dm_dt_task_object task
	    on task.id = t.taskid
	  left join pm_task_status status
	    on t.statusid = status.status_id
	   and status.group_id = 'DataObjectStatus'
	  left join file_filedesc f
	    on t.filevalue = f.pid
	  left join data_unit du
	    on t.unitid = du.english_name
/

