create view P2M_TO_KE_ENGINEER as
  select d11.taskid taskId,
               d12.template_id templateId,
               d12.template_name templateName,
               d12.template_brief templateBrief,
               d12.description description,
               d12.specialty_sort specialtySort,
               d13.fixed_revision revision
          from dm_dt_task_bind_engineer d11,
               ide_template d12,
               data_version d13
         where d11.engineertemplateid = d12.template_id
           and d11.engineertemplaterevision = d12.revision
           and d12.template_id = d13.object_id
           and d12.revision = d13.fixed_revision
           and d11.taskid in
               (SELECT o.id
                  FROM dm_dt_task_object o
                 WHERE o.modelTypeId = 'taskModel'
                   and o.statusid not in ('deleted', 'disable')
                   AND o.id IN (select max(l.id) maxId
                                  from dm_dt_version v, dm_dt_link l
                                 where v.id = l.id
                                 group by l.srclinkedid))
        union
        select d21.taskid taskId,
               d22.template_id templateId,
               d22.template_name templateName,
               d22.template_brief templateBrief,
               d22.description description,
               d22.specialty_sort specialtySort,
               d23.fixed_revision revision
          from dm_dt_task_bind_engineer d21,
               ide_template_old d22,
               data_version d23
         where d21.engineertemplateid = d22.template_id
           and d21.engineertemplaterevision = d22.revision
           and d22.template_id = d23.object_id
           and d22.revision = d23.fixed_revision
           and d21.taskid in
               (SELECT o.id
                  FROM dm_dt_task_object o
                 WHERE o.modelTypeId = 'taskModel'
                   and o.statusid not in ('deleted', 'disable')
                   AND o.id IN (select max(l.id) maxId
                                  from dm_dt_version v, dm_dt_link l
                                 where v.id = l.id
                                 group by l.srclinkedid))
/

