create view P2M_MYTASK as
  SELECT
		    t."ID",t."CODE",t."NAME",t."STATUSID",t."PRESTATUSID",t."PRIORITYID",t."PROGRESSFEEDBACKID",t."SECURITYDEGREEID",t."PLANNEDWORKINGDATE",t."PLANNEDSTARTTIME",t."PLANNEDENDTIME",t."ACTUALWORKINGDATE",t."ACTUALSTARTTIME",t."ACTUALENDTIME",t."CHARGEDEPARTMENTID",t."PARTICIPATEDEPARTMENTID",t."CHARGEMANID",t."PARTICIPATEMANID",t."CREATORID",t."CREATETIME",t."UPDATERID",t."UPDATETIME",t."DESCRIPTION",t."SUBPROCESSID",t."ENGINEERTEMPLATEID",t."MODELID",t."MODELTYPEID",t."PROJECTPHASEID",t."PROGRESSPERCENTAGE",t."PROGRESSDESCRIPTION",t."REVISION",t."ROWSTATUSID",t."ADJUSTSTATUSID",t."PROJECTID",t."TRACKMANID",t."ENGINEERINSTANCEID",t."OUTERSYSTYPE",t."OUTERSYSID",t."DISCIPLINE",t."TEMPLATECODE",t."ENGINEERREVISION",t."RELATEDTASKTEMPLATEID",t."APPLYCODE",t."PROJECTTEAMROLE",t."EXEASK",t."SOURCE",t."DEPARTMENTTYPE",t."ACTUALCOSTS",t."COSTS",t."CONSTRAINTTYPE",t."CONSTRAINTDATE",t."PLANHOUR",t."TASKLANDMARKID",t."DEFAULTSET",t."ARRAYLENGTH",t."RELATIVEPATH",t."DIMENSION",t."RELATIONID",t."PARENTMODELID",t."PARENTID",t."CHILDMODELID",t."CHILDID",t."SORTORDER",t."WBSCODE",t."TREEPATH",t."RELATIONTYPE",t."RELATIONREVISION",t."RELATIONROWSTATUSID",t."PARENTMODELTYPEID",t."CHILDMODELTYPEID",t."PARENTNAME",t."PARENTSTATUSID",t."PARENTSTATUSNAME",t."PROJECTNAME",t."STATUSNAME",t."PRESTATUSNAME",t."SUBPROCESSNAME",t."PRIORITYNAME",t."PROGRESSFEEDBACKNAME",t."PROJECTPHASENAME",t."ENGINEERTEMPLATENAME",t."LEAFCOUNT",t."OPERATIONMODELCOUNT",
		    p.participant_id      as participantId,
		    p.participant_type    as participantType,
		    p.participant_group   as participantGroup,
		    p.row_status          as participateRowStatus,
		    p.operation           as operation,
		    p.self_man_hour       as selfManHour,
		   (SELECT COUNT(*)
		    FROM pm_task_remind v
		    WHERE v.task_id = t.id
		    AND to_date(
		      CASE v.time_type
		        WHEN 0
		        THEN v.remind_day
		        WHEN 1
		        THEN (
		          CASE v.time_edge
		            WHEN 1
		            THEN TO_CHAR(t.PLANNEDSTARTTIME - v.remind_day, 'yyyy-mm-dd')
		            WHEN 2
		            THEN TO_CHAR(t.PLANNEDSTARTTIME + v.remind_day, 'yyyy-mm-dd')
		          END)
		        WHEN 2
		        THEN (
		          CASE v.time_edge
		            WHEN 1
		            THEN TO_CHAR(t.PLANNEDENDTIME - v.remind_day, 'yyyy-mm-dd')
		            WHEN 2
		            THEN TO_CHAR(t.PLANNEDENDTIME + v.remind_day, 'yyyy-mm-dd')
		          END)
		      END, 'yyyy-mm-dd') >= to_date(TO_CHAR(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd')
		    ) AS isRemind,
		    (SELECT COUNT(*)
		    FROM SYS_USER_AGENCY a
		    WHERE a.object_id = t.id
		    AND a.status      = 0
		    ) AS isAgency,
		    (SELECT COUNT(*) FROM SYS_USER_AGENCY a WHERE a.object_id = t.id
		    ) AS isNote
		  FROM        --嵌套P2M_TASK视图                            
		   (  
 		select t.*,
	r."RELATIONID",
	r."PARENTMODELID",
	r."PARENTID",
	r."CHILDMODELID",
	r."CHILDID",
	r."SORTORDER",
	r."WBSCODE",
	r."TREEPATH",
	r."RELATIONTYPE",
	r."REVISION" relationRevision,
	r."ROWSTATUSID" relationRowStatusId,
	parent.modeltypeid parentModelTypeId,
	t.modelTypeid childModelTypeId,
	parent.name                       parentname, --父任务名称
	parent.statusid                   parentStatusId,--父任务状态
	parentstatus.status_name          parentStatusName,--父任务状态名称
	project.name                      projectname, --项目
	status.status_name                statusname, --状态名称
	prestatus.status_name             prestatusname, --前状态名称
	process.process_name              subprocessname, --子流程
	priority.name                     priorityName, --优先级
	progressFeedback.name             progressFeedbackName, --进度反馈方式
	projectPhase.name                 projectPhaseName,--项目阶段
	--versionName
	ideTemplate.Template_Name  engineerTemplateName,--工程模板库名称
	--modelname
	--modeltypename
	--rowstatusname
	--adjuststatusname
	--spendtimeamout
	       (select count(*)
	              from pm_wbs_relation r, pm_task_object c
	             where c.id = r.childid
	               and r.parentid = t.id ) as leafCount,--子节点数量
	       (select count(*)
	              from pm_wbs_relation r, pm_task_object c
	             where c.id = r.childid
	               and r.parentid = t.id and  c.modeltypeid ='operationProcessModel') as operationModelCount--子流程任务数量
	  from pm_task_object t
	 inner join pm_wbs_relation r
	    on t.id = r.childid
	  left join pm_task_object parent
	    on parent.id = r.parentid
	  left join pm_task_object project
	    on t.projectid = project.id
	  left join pm_task_status status
	    on t.statusid = status.status_id
	   and status.group_id = 'TaskStatus'
	  left join pm_task_status prestatus
	    on t.prestatusid = prestatus.status_id
	   and prestatus.group_id = 'TaskStatus'
	  left join pm_task_status parentstatus
	    on t.prestatusid = parentstatus.status_id
	   and parentstatus.group_id = 'TaskStatus'
	  left join engine_process process
	    on t.subprocessid = process.process_id
	  left join pm_enumattribute priority
	    on t.priorityid = priority.enum_attribute_id
	   and priority.code = 'importantLevel'
	  left join pm_enumattribute progressFeedback
	    on t.progressFeedbackId = progressFeedback.enum_attribute_id
	   and progressFeedback.code = 'progressFeedbackId'
	  left join pm_enumattribute projectPhase
	    on t.projectPhaseId = projectPhase.enum_attribute_id
	   and projectPhase.code = 'Phase'
	   left join ide_template ideTemplate
	  on ideTemplate.TEMPLATE_ID = t.ENGINEERTEMPLATEID
 		
 	 )
		   t,                        
		    pm_task_participant p
		  WHERE t.id = p.task_id
/

