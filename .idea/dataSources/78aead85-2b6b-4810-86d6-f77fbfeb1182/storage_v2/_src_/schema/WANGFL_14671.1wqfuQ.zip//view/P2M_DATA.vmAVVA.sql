create view P2M_DATA as
  SELECT t."ID",t."CODE",t."MODELTYPEID",t."MODELID",t."NAME",t."CREATORID",t."CREATETIME",t."UPDATERID",t."UPDATETIME",t."SECURITYDEGREEID",t."STATUSID",t."DESCRIPTION",t."ROWSTATUSID",t."REVISION",t."CHANGED",t."VERSIONNAME",t."BOOLEANVALUE",t."DATEVALUE",t."DOUBLEVALUE",t."STRINGVALUE",t."INTVALUE",t."UNITID",t."TASKID",t."FILEVALUE",t."OUTERSYSTYPE",t."OUTERSYSID",t."OUTERSTATUS",t."OUTERMODELURL",t."OUTERURL",t."LOCKERID",t."DISCIPLINE",t."PROJECTPHASEID",t."TEMPLATECODE",t."IMPORTTYPE",t."TRANSITIONID",t."ARRAYLENGTH",t."DIMENSION",t."RELATIVEPATH",t."PDMURL",t."ISLINKPDM",t."DEPARTMENTTYPE",t."OWNERID",t."SHARESTATUSID",t."DEFAULTSET",t."RELATEDTASKTEMPLATEDATAID",t."APPLYCODE",t."URLVALUE",t."ENGINEERTEMPLATEREVISION",t."ENGINEERTEMPLATEID",t."ACCEPTSPECIALTYID",t."SOURCETYPE",t."DATACENTERREVISION",t."DATACENTERVERSIONNAME",t."TRACKMANID",t."SOURCE",t."EXEASK",
           r.RELATIONID,
           r.RELATIONTYPE,
           r.PARENTMODELTYPEID,
           r.PARENTMODELID,
           r.PARENTID,
           r.CHILDMODELTYPEID,
           r.CHILDMODELID,
           r.CHILDID,
           r.SORTORDER,
           r.WBSCODE,
           r.TREEPATH,
           r.REVISION relationRevision,
           r.ROWSTATUSID relationRowStatusId,
           r.REFID,
           r.REFREVISION,
           r.REFTYPE,
           r.REFEDITABLE,
           TO_CHAR (t."CREATETIME", 'yyyy-mm-dd hh24:mi:ss') AS createtimestr,
           TO_CHAR (t."UPDATETIME", 'yyyy-mm-dd hh24:mi:ss') AS updatetimestr,
           CASE
              WHEN t.filevalue IS NOT NULL
              THEN
                 '' || f.filename
              WHEN t.urlvalue IS NOT NULL
              THEN
                 t.urlvalue
              WHEN t.STRINGVALUE IS NOT NULL
              THEN
                 t.STRINGVALUE
              WHEN t.datevalue IS NOT NULL
              THEN
                 TO_CHAR (t.datevalue, 'yyyy-mm-dd hh24:mi:ss')
              WHEN t.booleanvalue IS NOT NULL
              THEN
                 '' || t.booleanvalue
              WHEN t.doublevalue IS NOT NULL
              THEN
                 TO_CHAR (t.doublevalue, '99999999999990.999999')
              WHEN t.INTVALUE IS NOT NULL
              THEN
                 '' || t.INTVALUE
           END
              AS VALUE,
           (SELECT wm_concat (DISTINCT (s.relationType))
              FROM pm_association_relation s
             WHERE s.targetid = t.id)
              AS relationCode,
           status.status_name statusName,
           sharedStatus.status_name sharedStatusName,
           u.unit_name unitName,
           task.name taskName,
           task.projectId projectId,
           (SELECT COUNT (*)
              FROM pm_structure_relation r
             WHERE r.parentid = t.id)
              AS leafCount,
           '' securityvalue,
           '' securitydegreename,
           '' creatorName,
           '' updaterName,
           '' ownerName,
           '' lockerName,
           '' transferstatusid,
           '' parentTaskId,
           '' AS UPPER,
           '' AS LOWER,
           '' AS parentName
      FROM (SELECT d.*
              FROM pm_data_object d
                   LEFT JOIN pm_structure_relation r ON d.id = r.childid
             WHERE    r.relationType IN ('StructureRelation', 'CopyRelation')
                   OR (    r.relationType IN
                              ('ReferenceRelation',
                               'TransportRelation',
                               'AssignmentRelation')
                       AND r.refType = 0)
            UNION
            SELECT d.*
              FROM pm_data_object_old d
                   LEFT JOIN pm_structure_relation r
                      ON d.id = r.childid AND r.refrevision = d.revision
             WHERE     r.relationType IN
                          ('ReferenceRelation',
                           'TransportRelation',
                           'AssignmentRelation')
                   AND r.refType = 1) t
           LEFT JOIN pm_structure_relation r ON t.id = r.childid
           LEFT JOIN
           pm_task_status status
              ON     t.statusid = status.status_id
                 AND status.GROUP_ID = 'DataObjectStatus'
           LEFT JOIN
           pm_task_status sharedStatus
              ON     t.sharestatusid = sharedStatus.status_id
                 AND sharedStatus.GROUP_ID = 'DataSharedStatus'
           LEFT JOIN data_unit u ON t.unitid = u.english_name
           LEFT JOIN file_filedesc f
              ON t.filevalue = f.pid AND t.fileValue IS NOT NULL
           LEFT JOIN pm_task_object task ON task.id = t.taskid
/

