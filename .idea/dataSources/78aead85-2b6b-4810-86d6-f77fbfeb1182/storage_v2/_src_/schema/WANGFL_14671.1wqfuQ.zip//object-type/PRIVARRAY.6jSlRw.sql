create TYPE "PRIVARRAY"                                                                                                                                as table OF NUMBER
/

