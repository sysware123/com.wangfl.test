create function getSrcDataTemplateId(relatedtasktemplatedataid in varchar2)
  return varchar2 as
  srcDataId    varchar2(400);
  count_number number;

begin
  --鍑芥暟瀹氫箟锛氱爺鍙戞ā鏉跨増鏈満鏅腑锛屼緷鎹甈2M绔殑浠诲姟鏁版嵁鐨剅elatedtasktemplatedataid灞炴?鍊硷紝鑾峰彇鍏跺搴旂殑鏁版嵁妯℃澘ID
  --鎯呭喌0: relatedtasktemplatedataid涓虹┖鐨勬儏鍐垫湭閫昏緫鏄炬?鍖?

  --鎯呭喌1锛氶?杩囧湪P2M绔鍏ユ暟鎹ā鏉跨敓鎴愮殑浠诲姟鏁版嵁锛屼笖婧愭暟鎹ā鏉垮瓨鍦?
  if srcDataId is null then
    select count(1)
      into count_number
      from dm_dt_version v
     where v.id = relatedtasktemplatedataid;
    if count_number = 1 then
      srcDataId := relatedtasktemplatedataid;
    end if;
  end if;
  --鎯呭喌2锛氶?杩囧湪P2M绔鍏ユ暟鎹ā鏉跨敓鎴愮殑浠诲姟鏁版嵁锛屼笖婧愭暟鎹ā鏉胯鍒犻櫎
  if srcDataId is null then
    select count(1)
      into count_number
      from dm_dt_srcdatatemplate s
     where s.srcdatatemplateid = relatedtasktemplatedataid;
    if count_number > 0 then
      srcDataId := relatedtasktemplatedataid;
    end if;
  end if;
  --鎯呭喌3锛氶?杩囧簲鐢ㄧ爺鍙戞ā鏉跨増鏈璞＄敓鎴愮殑浠诲姟鏁版嵁
  if srcDataId is null then
    select count(1)
      into count_number
      from dm_dt_srcdatatemplate s
     where s.id = relatedtasktemplatedataid;
    if count_number > 0 then
      select s.srcdatatemplateid
        into srcDataId
        from dm_dt_srcdatatemplate s
       where s.id = relatedtasktemplatedataid;
    end if;
  end if;

  return(srcDataId);

end getSrcDataTemplateId;
/

