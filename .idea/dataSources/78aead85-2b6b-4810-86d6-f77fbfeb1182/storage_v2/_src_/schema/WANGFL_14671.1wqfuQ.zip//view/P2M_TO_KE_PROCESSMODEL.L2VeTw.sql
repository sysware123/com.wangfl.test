create view P2M_TO_KE_PROCESSMODEL as
  SELECT p.name           phaseName, --流程模板所属部门名称--
       o.departmenttype phaseEnumId,--流程模板所属部门ID--
       o.discipline     specialtyEnumId,--流程模板所属专业名称--
       pe.name          specialtyName,--流程模板所属专业ID--
       o.name           taskName,--流程模板名称--
       o.modelid        modelid,--流程模板类型--
       o.id             taskId,--流程模板ID--
       o.createtime     updateTime,--更新时间--
       o.description    description
  FROM dm_dt_task_object o, PM_EnumAttribute p, PM_EnumAttribute pe
 WHERE o.departmenttype = p.enum_attribute_id
   and o.discipline = pe.enum_attribute_id
   and o.modelTypeId = 'processModel'
   and o.statusid not in ('deleted', 'disable')
   AND o.id IN (select max(l.id) maxId
                  from dm_dt_version v, dm_dt_link l
                 where v.id = l.id
                 group by l.srclinkedid)
/

