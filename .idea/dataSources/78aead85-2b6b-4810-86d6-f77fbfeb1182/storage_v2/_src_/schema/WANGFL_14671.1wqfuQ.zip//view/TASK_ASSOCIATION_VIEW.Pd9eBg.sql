create view TASK_ASSOCIATION_VIEW as
  SELECT r.activity_data_relation_id AS rid,
					   fac.action_id AS srcId,
					   fac.action_name AS srcName,
					   ta.activity_id AS targetId,
					   ta.activity_name AS targetName,
					   'A' AS TYPE
				  FROM engine_activity_data_relation r
				  LEFT JOIN engine_activity fa
					ON r.from_activity_id = fa.activity_id
				  LEFT JOIN engine_activity_action fac
					ON fa.activity_id = fac.activity_id
				  LEFT JOIN engine_activity ta
					ON r.to_activity_id = ta.activity_id
				 WHERE r.relationtype = 'DATA'
				   and fa.activity_type = 'TASK_ACTIVITY'
				   and Ta.activity_type <> 'TASK_ACTIVITY'
				UNION

				SELECT r.activity_data_relation_id AS rid,
					   fa.activity_id AS srcId,
					   fa.activity_name AS srcName,
					   tac.action_id AS targetId,
					   tac.action_name AS targetName,
					   'A' AS TYPE
				  FROM engine_activity_data_relation r
				  LEFT JOIN engine_activity fa
					ON r.from_activity_id = fa.activity_id
				  LEFT JOIN engine_activity ta
					ON r.to_activity_id = ta.activity_id
				  LEFT JOIN engine_activity_action tac
					ON ta.activity_id = tac.activity_id
				 WHERE r.relationtype = 'DATA'
				   and fa.activity_type <> 'TASK_ACTIVITY'
				   and Ta.activity_type = 'TASK_ACTIVITY'
				UNION

				SELECT r.activity_data_relation_id AS rid,
					   fac.action_id AS srcId,
					   fac.action_name AS srcName,
					   tac.action_id AS targetId,
					   tac.action_name AS targetName,
					   'A' AS TYPE
				  FROM engine_activity_data_relation r
				  LEFT JOIN engine_activity fa
					ON r.from_activity_id = fa.activity_id
				  LEFT JOIN engine_activity_action fac
					ON fa.activity_id = fac.activity_id
				  LEFT JOIN engine_activity ta
					ON r.to_activity_id = ta.activity_id
				  LEFT JOIN engine_activity_action tac
					ON ta.activity_id = tac.activity_id
				 WHERE NVL(fac.action_id, '0') <> '0'
				   AND NVL(tac.action_id, '0') <> '0'
				   AND r.relationtype = 'DATA'
				   and fa.activity_type = 'TASK_ACTIVITY'
				   and Ta.activity_type = 'TASK_ACTIVITY'
				UNION
				SELECT aso.relationid AS rid,
					   aso.srctaskid AS srcId,
					   ftc.name AS srcName,
					   aso.targettaskid AS targetId,
					   ttc.name AS targetName,
					   'B' AS TYPE
				  FROM pm_task_association aso
				  LEFT JOIN pm_task_object ftc
					ON aso.srctaskid = ftc.id
				  LEFT JOIN pm_task_object ttc
					ON aso.targettaskid = ttc.id
				UNION
				SELECT r.activity_data_relation_id AS rid,
					   ta.id AS srcId,
					   ta.name AS srcName,
					   fac.action_id AS targetId,
					   fac.action_name AS targetName,
					   'C2' AS TYPE
				  FROM engine_activity_data_relation r
				  LEFT JOIN engine_process pb
					ON R.FROM_ACTIVITY_ID = Pb.start_NODE_ID
				  LEFT JOIN engine_activity_action fac
					ON R.to_ACTIVITY_ID = fac.activity_id
				  LEFT JOIN pm_task_object ta
					ON TA.SUBPROCESSID = pb.process_id
				 WHERE NVL(pb.process_id, '0') <> '0'
				   and r.relationtype = 'DATA'
/

