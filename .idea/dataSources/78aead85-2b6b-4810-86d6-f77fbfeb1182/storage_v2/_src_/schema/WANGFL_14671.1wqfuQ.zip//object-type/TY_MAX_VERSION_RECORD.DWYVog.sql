create TYPE TY_MAX_VERSION_RECORD AS OBJECT
( /* TODO enter attribute and method declarations here */
    id    VARCHAR2(40 BYTE),
    max_v NUMBER(20,0),
    max_t NUMBER(20,0),
    max_r NUMBER(20,0)
)
/

