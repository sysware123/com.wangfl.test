create function PM_WBS_CORD_SORT(p_list      varchar2,
                                            p_sep       varchar2 := '.',
                                            p_formatStr varchar2 := 'fm0000')
  return varchar2 is
  Result  varchar2(4000) := '';
  v_index pls_integer;
  v_list  varchar2(4000) := p_list;
begin
  loop
    v_index := instr(v_list, p_sep);
    if v_index > 0 then
      Result := Result ||
                to_char(substr(v_list, 1, v_index - 1), p_formatStr);
      v_list := substr(v_list, v_index + length(p_sep));
    else
      Result := Result || to_char(v_list, p_formatStr);
      exit;
    end if;
  end loop;
  return(Result);
end PM_WBS_CORD_SORT;
/

