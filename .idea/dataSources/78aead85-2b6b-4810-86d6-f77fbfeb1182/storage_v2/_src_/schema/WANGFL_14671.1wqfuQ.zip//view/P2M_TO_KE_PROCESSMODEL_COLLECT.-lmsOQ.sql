create view P2M_TO_KE_PROCESSMODEL_COLLECT as
  select tt."ID",tt."CODE",tt."NAME",tt."STATUSID",tt."PRESTATUSID",tt."PRIORITYID",tt."PROGRESSFEEDBACKID",tt."SECURITYDEGREEID",tt."PLANNEDWORKINGDATE",tt."PLANNEDSTARTTIME",tt."PLANNEDENDTIME",tt."ACTUALWORKINGDATE",tt."ACTUALSTARTTIME",tt."ACTUALENDTIME",tt."CHARGEDEPARTMENTID",tt."PARTICIPATEDEPARTMENTID",tt."CHARGEMANID",tt."PARTICIPATEMANID",tt."CREATORID",tt."CREATETIME",tt."UPDATERID",tt."UPDATETIME",tt."DESCRIPTION",tt."SUBPROCESSID",tt."ENGINEERTEMPLATEID",tt."MODELID",tt."MODELTYPEID",tt."PROJECTPHASEID",tt."PROGRESSPERCENTAGE",tt."PROGRESSDESCRIPTION",tt."REVISION",tt."ROWSTATUSID",tt."ADJUSTSTATUSID",tt."PROJECTID",tt."TRACKMANID",tt."DISCIPLINE",tt."PROCESSTYPE",tt."IMPORT_FLAG",tt."TEMPLATECODE",tt."DEPARTMENTTYPE",tt."ENGINEERREVISION",tt."PROJECTTEAMROLE",tt."EXEASK",tt."SOURCE",tt."VERSIONNAME",tt."OFFICIAL",o2.srclinkedid as LINK_ID
  from (select 'V' || max(to_number(substr(v.versionname, 2))) maxVersionName,
               l.srclinkedid
          from dm_dt_version v, dm_dt_link l
         where v.id = l.id
         group by l.srclinkedid) o1,
       (select v.id, v.versionname, l.srclinkedid
          from dm_dt_version v, dm_dt_link l
         where v.id = l.id) o2,
       dm_dt_task_object tt
 where o1.srclinkedid = o2.srclinkedid
   and o1.maxVersionName = o2.versionname
   and o2.id = tt.id
   and o2.srclinkedid in (
                          select t.id
                            from dm_dt_task_object t, dm_dt_wbs_relation w
                           where t.id = w.childid
                             and w.parentid = '1'
                             and t.modeltypeid = 'processModel'
                             and t.STATUSID = 'running')
/

