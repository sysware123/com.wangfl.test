create view P2M_TO_KE_ACTIVEMODEL_DATA as
  select p.name phaseName,--鏁版嵁鎵?睘閮ㄩ棬鍚嶇О--
       t.departmenttype phaseEnumId,--鏁版嵁鎵?睘閮ㄩ棬ID--
       t.discipline     specialtyEnumId,--鏁版嵁鎵?睘涓撲笟ID--
       pe.name          specialtyName,--鏁版嵁鎵?睘涓撲笟鍚嶇О--
       t.taskid             taskId,--鏁版嵁ID--
       t.name           name,--鏁版嵁鍚嶇О--
       t.modelid        modelid --鏁版嵁绫诲瀷--
  from dm_dt_data_object t, PM_EnumAttribute p, PM_EnumAttribute pe
 where t.departmenttype = p.enum_attribute_id
   and t.discipline = pe.enum_attribute_id
   and t.taskid in (SELECT o.id
                      FROM dm_dt_task_object o
                     WHERE o.modelTypeId = 'taskModel'
                       and o.statusid not in ('deleted', 'disable')
                       AND o.id IN (select max(l.id) maxId
                                      from dm_dt_version v, dm_dt_link l
                                     where v.id = l.id
                                     group by l.srclinkedid))
/

