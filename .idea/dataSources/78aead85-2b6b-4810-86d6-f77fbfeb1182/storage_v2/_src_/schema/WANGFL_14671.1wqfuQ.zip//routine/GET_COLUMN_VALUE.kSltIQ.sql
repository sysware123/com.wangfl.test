create FUNCTION GET_COLUMN_VALUE(TABLENAME       IN VARCHAR2,
                                            PRIMARYKEYNAME  IN VARCHAR2,
                                            PRIMARYKEYVALUE IN VARCHAR2,
                                            COLUMNNAME      IN VARCHAR2)
  RETURN VARCHAR2 IS

  QUERYSQL                 VARCHAR2(4000);
  COLUMNVALUE              VARCHAR2(4000);
  DATATYPESQL              VARCHAR2(4000);
  DATATYPE                 VARCHAR2(4000);
BEGIN
  DATATYPESQL := 'select data_type from user_tab_columns t where t.TABLE_NAME=upper(''' ||
                 TABLENAME || ''')  and  t.COLUMN_NAME=upper(''' ||
                 COLUMNNAME || ''')';
  EXECUTE IMMEDIATE DATATYPESQL
    INTO DATATYPE;
  IF (DATATYPE IS NULL) THEN
    COLUMNVALUE := '';
  ELSE
    IF ((DATATYPE = 'TIMESTAMP(6)') OR (DATATYPE = 'DATE')) THEN
      QUERYSQL := 'select to_char(' || COLUMNNAME ||
                  ',''yyyy-mm-dd hh24:mi:ss'') from ' || TABLENAME ||
                  ' where ' || PRIMARYKEYNAME || ' = ''' || PRIMARYKEYVALUE || '''';
      EXECUTE IMMEDIATE QUERYSQL
        INTO COLUMNVALUE;
    ELSE
      QUERYSQL := 'select ' || COLUMNNAME || ' from ' || TABLENAME ||
                  ' where ' || PRIMARYKEYNAME || ' = ''' || PRIMARYKEYVALUE || '''';
      EXECUTE IMMEDIATE QUERYSQL
        INTO COLUMNVALUE;
    END IF;
  END IF;
  RETURN(COLUMNVALUE);
END GET_COLUMN_VALUE;
/

