create TYPE "VCARRAY"                                                                          as table of varchar2(4000)
/

