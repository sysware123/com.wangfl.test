create TYPE "PRIV_AND"                                                                                                                                AS OBJECT
(
  PRIV privarray,
  STATIC FUNCTION ODCIAGGREGATEINITIALIZE(SCTX IN OUT PRIV_AND)
    RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATEITERATE(SELF  IN OUT PRIV_AND,
                                       VALUE IN NUMBER) RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATETERMINATE(SELF        IN PRIV_AND,
                                         RETURNVALUE OUT NUMBER,
                                         FLAGS       IN NUMBER)
    RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATEMERGE(SELF IN OUT PRIV_AND,
                                     CTX  IN PRIV_AND) RETURN NUMBER
)
/

