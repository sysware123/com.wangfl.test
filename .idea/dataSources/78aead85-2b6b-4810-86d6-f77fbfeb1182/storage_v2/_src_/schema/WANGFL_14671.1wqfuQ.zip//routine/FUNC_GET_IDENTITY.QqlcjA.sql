create FUNCTION FUNC_GET_IDENTITY return varchar2 is
  Result varchar2(40);
begin
  Result := TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFF6') ||
            substr(SYS_GUID(), 0, 20);
  return(Result);
end Func_Get_Identity;
/

