create view P2M_TO_KE_IDETEMPLATE_DATA as
  select q.template_id    templateId, /*模板Id*/
         p.name           dataName, /*名称*/
         p.modelid        modelId, /* 类型*/
         p.departmenttype phaseEnumId, /* 阶段ID*/
         pm.name          phaseName, /* 阶段名称*/
         p.discipline     specialtyEnumId, /* 专业ID*/
         pe.name          specialtyName, /* 专业名称*/
         ff.fileName      fileName, /*值名称*/
         p.description    description /* 描述*/
    from pm_data_object p
    left join PM_EnumAttribute pe
      on p.discipline = pe.enum_attribute_id
    left join PM_EnumAttribute pm
      on p.departmenttype = pm.enum_attribute_id
    left join file_filedesc ff
      on p.fileValue = ff.pid
   right join (select f.template_id,
                      f.template_id || '_' || f.revision as tt
                 from (select t.template_id, t.revision
                         from ide_template_group_relation r,
                              ide_template                t,
                              data_version                d
                        where r.template_id = t.template_id
                          and t.template_id = d.object_id
                          and t.revision = d.fixed_revision
                          and (t.row_status not in ('0', '1', '3', '4'))
                       union
                       select t.template_id, t.revision
                         from ide_template_old t,
                              ide_template_group_relation r,
                              data_version d,
                              (select t.template_id,
                                      max(d.fixed_revision) fixed_revision
                                 from ide_template_group_relation r,
                                      ide_template                t,
                                      data_version                d
                                where r.template_id = t.template_id
                                  and d.object_id = t.template_id
                                  and t.row_status in ('0', '3')
                                group by t.template_id) k
                        where t.template_id = d.object_id
                          and t.template_id = r.template_id
                          and t.template_id = k.template_id
                          and t.revision = k.fixed_revision
                          and d.fixed_revision = k.fixed_revision
                       union
                       select t.template_id, t.revision
                         from ide_template_old t,
                              ide_template_group_relation r,
                              data_version d,
                              (select dv.object_id,
                                      max(dv.fixed_revision) fixed_revision
                                 from data_version dv,
                                      (select t.template_id,
                                              max(d.fixed_revision) fixed_revision
                                         from ide_template_group_relation r,
                                              ide_template                t,
                                              data_version                d
                                        where r.template_id = t.template_id
                                          and d.object_id = t.template_id
                                          and t.row_status in ('1', '4')
                                        group by t.template_id) k
                                where dv.object_id = k.template_id
                                  and dv.fixed_revision != k.fixed_revision
                                group by dv.object_id) k
                        where t.template_id = d.object_id
                          and t.template_id = r.template_id
                          and t.template_id = k.object_id
                          and k.fixed_revision = t.revision
                          and d.fixed_revision = k.fixed_revision) f) q
      on p.taskid = q.tt
/

