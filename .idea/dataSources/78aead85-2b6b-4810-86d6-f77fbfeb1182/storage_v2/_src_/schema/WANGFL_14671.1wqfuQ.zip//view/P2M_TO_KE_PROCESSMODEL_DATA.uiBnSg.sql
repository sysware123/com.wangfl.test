create view P2M_TO_KE_PROCESSMODEL_DATA as
  select p.name           phaseName,--数据所属部门名称--
       t.departmenttype phaseEnumId,--数据所属部门ID--
       t.discipline     specialtyEnumId,--数据所属专业ID--
       pe.name          specialtyName,--数据所属专业名称--
       t.taskid             taskId,--数据ID--
       t.name           name,--数据名称--
       t.modelid        modelid --数据类型--
  from dm_dt_data_object t, PM_EnumAttribute p, PM_EnumAttribute pe
 where t.departmenttype = p.enum_attribute_id
   and t.discipline = pe.enum_attribute_id
   and t.taskid in (SELECT o.id
                      FROM dm_dt_task_object o
                     WHERE o.modelTypeId = 'processModel'
                       and o.statusid not in ('deleted', 'disable')
                       AND o.id IN (select max(l.id) maxId
                                      from dm_dt_version v, dm_dt_link l
                                     where v.id = l.id
                                     group by l.srclinkedid))
/

