create view P2M_TO_KE_IDETEMPLATE as
  select t.template_id     templateId,/*模版id*/
        t.template_name   templateName,/*名称*/
        t.specialty_sort  specialtySort,/*专业*/
        t.row_update_time updateTime,/*更新时间*/
        t.description     description /*描述*/
   from ide_template_group_relation r, ide_template t, data_version d
  where r.template_id = t.template_id
    and t.template_id = d.object_id
    and t.revision = d.fixed_revision
    and (t.row_status not in ('0', '1', '3', '4'))
 union
 select t.template_id     templateId,
        t.template_name   templateName,
        t.specialty_sort  specialtySort,
        t.row_update_time updateTime,
        t.description     description
   from ide_template_old t,
        ide_template_group_relation r,
        data_version d,
        (select t.template_id, max(d.fixed_revision) fixed_revision
           from ide_template_group_relation r,
                ide_template                t,
                data_version                d
          where r.template_id = t.template_id
            and d.object_id = t.template_id
            and t.row_status in ('0', '3')
          group by t.template_id) k
  where t.template_id = d.object_id
    and t.template_id = r.template_id
    and t.template_id = k.template_id
    and t.revision = k.fixed_revision
    and d.fixed_revision = k.fixed_revision
 union
 select t.template_id     templateId,
        t.template_name   templateName,
        t.specialty_sort  specialtySort,
        t.row_update_time updateTime,
        t.description     description
   from ide_template_old t,
        ide_template_group_relation r,
        data_version d,
        (select dv.object_id, max(dv.fixed_revision) fixed_revision
           from data_version dv,
                (select t.template_id, max(d.fixed_revision) fixed_revision
                   from ide_template_group_relation r,
                        ide_template                t,
                        data_version                d
                  where r.template_id = t.template_id
                    and d.object_id = t.template_id
                    and t.row_status in ('1', '4')
                  group by t.template_id) k
          where dv.object_id = k.template_id
            and dv.fixed_revision != k.fixed_revision
          group by dv.object_id) k
  where t.template_id = d.object_id
    and t.template_id = r.template_id
    and t.template_id = k.object_id
    and k.fixed_revision = t.revision
    and d.fixed_revision = k.fixed_revision
/

