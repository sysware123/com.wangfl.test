create Function
my_timestamp
return varchar2
AS LANGUAGE JAVA NAME 'MyTimestamp.getTimestamp() return java.lang.String';
/

