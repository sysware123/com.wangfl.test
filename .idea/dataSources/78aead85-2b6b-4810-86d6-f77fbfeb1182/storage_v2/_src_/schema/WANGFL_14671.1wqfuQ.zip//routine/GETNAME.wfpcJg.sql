create PROCEDURE "GETNAME"(name out varchar2, --节点名称
                                      idx  in varchar2 --节点id
                                      )
--获取节点名称的过程
 AS
  node_name    varchar2(2000);
  count_number number;
begin
  if node_name is null then
    select count(*)
      into count_number
      from pm_task_object p
     where p.id = idx;
    if count_number = 1 then
      select p.name into node_name from pm_task_object p where p.id = idx; --查询是否是任务或者项目
    end if;
  else
    name := node_name;
  end if;

  if node_name is null then
    select count(*)
      into count_number
      from pm_data_object p
     where p.id = idx;
    if count_number = 1 then
      select p.name into node_name from pm_data_object p where p.id = idx; --查询是否是数据节点
    end if;
  else
    name := node_name;
  end if;

  if node_name is null then
    select count(*)
      into count_number
      from engine_activity e
     where e.activity_id = idx;
    if count_number = 1 then
      select e.activity_name
        into node_name
        from engine_activity e
       where e.activity_id = idx; --查询是否是活动
    end if;
  else
    name := node_name;
  end if;

  if node_name is null then
    select count(*)
      into count_number
      from dm_dt_task_object e
     where e.id = idx;
    if count_number = 1 then
      select e.name
        into node_name
        from dm_dt_task_object e
       where e.id = idx; --查询是否是研发活动模板
    end if;
  else
    name := node_name;
  end if;

  if node_name is null then
    select count(*)
      into count_number
      from dm_dt_data_object e
     where e.id = idx;
    if count_number = 1 then
      select e.name
        into node_name
        from dm_dt_data_object e
       where e.id = idx; --查询是否是研发数据模板
    end if;
  else
    name := node_name;
  end if;

  if node_name is null then
    select count(*)
      into count_number
      from engine_activity e
     where e.activity_id = idx;
    if count_number = 1 then
      select e.activity_name
        into node_name
        from engine_activity e
       where e.activity_id = idx; --查询是否是研发流程模板
    end if;
  else
    name := node_name;
  end if;


END;
/

