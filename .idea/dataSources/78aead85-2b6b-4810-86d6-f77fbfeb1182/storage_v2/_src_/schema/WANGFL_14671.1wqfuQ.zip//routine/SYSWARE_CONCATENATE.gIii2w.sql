create FUNCTION sysware_concatenate(P1 varchar2)
 RETURN clob
  AGGREGATE USING type_concatenate;
/

