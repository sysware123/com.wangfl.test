create FUNCTION privilege_and(PRIV number) return number
  aggregate using priv_and;
/

