create function number_2to10 (v_num number) return varchar is
     v_rtn varchar(2000);
     v_n1 number;
     v_n2 number;
   begin
     v_n1 := v_num;
     loop
       v_n2 := mod(v_n1, 2);
       v_n1 := abs(trunc(v_n1 /2));
       v_rtn := to_char(v_n2) || v_rtn;
       exit when v_n1 = 0;
     end loop;
     return v_rtn;
   end;
/

