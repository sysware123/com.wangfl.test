create function number_2_bit(n_num number)
 return varchar is
   v_rtn varchar(2000);
   v_n1 number;
   v_n2 number;
   v_num number;
   v_sign char(1);
 begin
   v_num:=abs(n_num);
 if n_num < 0  then
       v_sign := '-';
 else
       v_sign := '';
 end if;
   v_n1:= v_num;
   loop
     v_n2 := mod(v_n1, 2);
     v_n1 := trunc(v_n1 / 2);
     v_rtn := to_char(v_n2) || v_rtn;
     exit when v_n1 = 0;
   end loop;
   return v_sign||v_rtn;
 exception
    when others then
    return(sqlerrm);
 end;
/

