create view SINGLE_P2M_DATA_OLD as
  SELECT t."ID",t."CODE",t."MODELTYPEID",t."MODELID",t."NAME",t."CREATORID",t."CREATETIME",t."UPDATERID",t."UPDATETIME",t."SECURITYDEGREEID",t."STATUSID",t."DESCRIPTION",t."ROWSTATUSID",t."REVISION",t."CHANGED",t."VERSIONNAME",t."BOOLEANVALUE",t."DATEVALUE",t."DOUBLEVALUE",t."STRINGVALUE",t."INTVALUE",t."UNITID",t."TASKID",t."FILEVALUE",t."OUTERSYSTYPE",t."OUTERSYSID",t."OUTERSTATUS",t."OUTERMODELURL",t."OUTERURL",t."LOCKERID",t."DISCIPLINE",t."PROJECTPHASEID",t."TEMPLATECODE",t."IMPORTTYPE",t."TRANSITIONID",t."ARRAYLENGTH",t."DIMENSION",t."RELATIVEPATH",t."PDMURL",t."ISLINKPDM",t."DEPARTMENTTYPE",t."OWNERID",t."SHARESTATUSID",t."DEFAULTSET",t."RELATEDTASKTEMPLATEDATAID",t."APPLYCODE",
  TO_CHAR(t."CREATETIME",'yyyy-mm-dd hh24:mi:ss') AS createtimestr,
  TO_CHAR(t."UPDATETIME",'yyyy-mm-dd hh24:mi:ss') AS updatetimestr,
  r."RELATIONID",
  r."RELATIONTYPE",
  r."PARENTMODELTYPEID",
  r."PARENTMODELID",
  r."PARENTID",
  r."CHILDMODELTYPEID",
  r."CHILDMODELID",
  r."CHILDID",
  r."SORTORDER",
  r."WBSCODE",
  r."TREEPATH",
  r."REVISION" relationRevision,
  r."ROWSTATUSID" relationRowStatusId,
  r."REFID",
  r."REFREVISION",
  r."REFTYPE",
  r."REFEDITABLE",
  CASE
    WHEN t.filevalue IS NOT NULL
    THEN ''
      ||f.filename
    WHEN t.STRINGVALUE IS NOT NULL
    THEN t.STRINGVALUE
    WHEN t.datevalue IS NOT NULL
    THEN TO_CHAR(t.datevalue,'yyyy-mm-dd hh24:mi:ss')
    WHEN t.booleanvalue IS NOT NULL
    THEN ''
      ||t.booleanvalue
    WHEN t.doublevalue IS NOT NULL
    THEN TO_CHAR(t.doublevalue,'99999999999990.999999')
    WHEN t.INTVALUE IS NOT NULL
    THEN ''
      ||t.INTVALUE
  END AS value,-- 值，value属性统一为字符串
  CASE
    WHEN (SELECT COUNT(*)
      FROM pm_association_relation s
      WHERE s.relationtype='MappingRelation'
      AND s.targetid      =t.id)>0
    THEN r.relationType
      ||',MappingRelation'
    ELSE r.relationtype
  END AS relationCode,
  status.status_name statusName,            --数据状态
  sharedStatus.status_name sharedStatusName,--共享数据状态
  u.abbreviation abbreviation,              --单位
  parent.name parentName,                   --父名称
  task.name taskName,                       --任务名称
  s.security_value securityvalue,           --密级值
  s.security_name securitydegreename,       --密级
  creator.user_name creatorName,            --创建人
  updater.user_name updaterName,            --更新人
  owner.user_name ownerName,                --所属人
  locker.user_name lockerName,              --锁定人,
  (SELECT COUNT(*) FROM pm_structure_relation r WHERE r.parentid = t.id
  ) AS leafCount --子节点数量，包含所有的关系类型
FROM pm_data_object_old t
LEFT JOIN pm_structure_relation r
ON t.id = r.childid
  --pm_data_object中的数据以及引用的pm_data_object中数据
AND ((r.relationType IN('StructureRelation','CopyRelation'))
OR (r.relationType   IN ('ReferenceRelation','TransportRelation','AssignmentRelation')
AND r.refType         =0))
LEFT JOIN pm_data_object parent
ON parent.id = r.parentid
LEFT JOIN pm_task_object task
ON task.id = t.taskid
LEFT JOIN sys_user creator
ON t.creatorid = creator.user_id
LEFT JOIN sys_user updater
ON t.updaterid = updater.user_id
LEFT JOIN sys_user owner
ON t.ownerid = owner.user_id
LEFT JOIN sys_user locker
ON t.LOCKERID = locker.user_id
LEFT JOIN sys_security_degree s
ON s.security_id = t.securitydegreeid
LEFT JOIN pm_task_status status
ON t.statusid       = status.status_id
AND status.group_id = 'DataObjectStatus'
LEFT JOIN pm_task_status sharedStatus
ON t.sharestatusid        = sharedStatus.status_id
AND sharedStatus.group_id = 'DataSharedStatus'
LEFT JOIN file_filedesc f
ON t.filevalue=f.pid
LEFT JOIN data_unit u
ON t.unitid=u.english_name
/

