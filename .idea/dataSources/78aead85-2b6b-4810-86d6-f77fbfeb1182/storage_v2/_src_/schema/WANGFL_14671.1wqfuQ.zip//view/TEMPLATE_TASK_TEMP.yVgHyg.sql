create view TEMPLATE_TASK_TEMP as
  select t."ID",t."CODE",t."NAME",t."STATUSID",t."PRESTATUSID",t."PRIORITYID",t."PROGRESSFEEDBACKID",t."SECURITYDEGREEID",t."PLANNEDWORKINGDATE",t."PLANNEDSTARTTIME",t."PLANNEDENDTIME",t."ACTUALWORKINGDATE",t."ACTUALSTARTTIME",t."ACTUALENDTIME",t."CHARGEDEPARTMENTID",t."PARTICIPATEDEPARTMENTID",t."CHARGEMANID",t."PARTICIPATEMANID",t."CREATORID",t."CREATETIME",t."UPDATERID",t."UPDATETIME",t."DESCRIPTION",t."SUBPROCESSID",t."ENGINEERTEMPLATEID",t."MODELID",t."MODELTYPEID",t."PROJECTPHASEID",t."PROGRESSPERCENTAGE",t."PROGRESSDESCRIPTION",t."REVISION",t."ROWSTATUSID",t."ADJUSTSTATUSID",t."PROJECTID",t."TRACKMANID",t."DISCIPLINE",t."PROCESSTYPE",t."IMPORT_FLAG",t."TEMPLATECODE",t."DEPARTMENTTYPE",t."ENGINEERREVISION",t."PROJECTTEAMROLE",t."EXEASK",t."SOURCE",t."VERSIONNAME",t."OFFICIAL",
	       r."RELATIONID",
	       r."PARENTMODELID",
	       r."PARENTID",
	       r."CHILDMODELID",
	       r."CHILDID",
	       r."SORTORDER",
	       r."WBSCODE",
	       r."TREEPATH",
	       r."RELATIONTYPE",
	       r."REVISION" relationRevision,
	       r."ROWSTATUSID" relationRowStatusId,
	       parent.modeltypeid parentModelTypeId,
	       parent.name parentname, --父任务名称
	       parent.statusid parentStatusId, --父任务状态
	       parentstatus.status_name parentStatusName, --父任务状态名称
	       project.name projectname, --项目
	       status.status_name statusname, --状态名称
	       prestatus.status_name prestatusname, --前状态名称
	       redundant.charged_man_name chargemanname, --负责人
	       redundant.assistant_man_name participatemanname, --协作人
	       redundant.charged_department_name chargedepartmentname, --负责部门
	       redundant.assistant_department_name participatedepartmentname, --协作部门
	       process.process_name subprocessname, --子流程
	       priority.name priorityName, --优先级
	       progressFeedback.name progressFeedbackName, --进度反馈方式
	       ideTemplate.Template_Name engineerTemplateName, --工程模板库名称
	       (select count(*)
	          from dm_dt_wbs_relation r, dm_dt_task_object c
	         where c.id = r.childid
	           and r.parentid = t.id) as dataLeafCount --子节点数量
	  from dm_dt_task_object t
	 inner join dm_dt_wbs_relation r
	    on t.id = r.childid
	  left join dm_dt_task_object parent
	    on parent.id = r.parentid
	  left join dm_dt_task_object project
	    on t.projectid = project.id
	  left join pm_task_object_redundant redundant
	    on redundant.task_id = t.id
	  left join pm_task_status status
	    on t.statusid = status.status_id
	   and status.group_id = 'TaskTemplateStatus'
	  left join pm_task_status prestatus
	    on t.prestatusid = prestatus.status_id
	   and prestatus.group_id = 'TaskTemplateStatus'
	  left join pm_task_status parentstatus
	    on t.prestatusid = parentstatus.status_id
	   and parentstatus.group_id = 'TaskTemplateStatus'
	  left join engine_process process
	    on t.subprocessid = process.process_id
	  left join pm_enumattribute priority
	    on t.priorityid = priority.enum_attribute_id
	   and priority.enum_type = 'Priority'
	  left join pm_enumattribute progressFeedback
	    on t.priorityid = progressFeedback.enum_attribute_id
	   and progressFeedback.enum_type = 'ProgressFeedback'
	  left join ide_template ideTemplate
	    on ideTemplate.TEMPLATE_ID = t.ENGINEERTEMPLATEID
/

