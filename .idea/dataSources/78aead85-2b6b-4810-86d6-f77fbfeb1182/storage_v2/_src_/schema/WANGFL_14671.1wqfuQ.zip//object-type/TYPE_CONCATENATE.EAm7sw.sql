create TYPE "TYPE_CONCATENATE"                                                                                                                                AUTHID CURRENT_USER AS OBJECT
(

  CURR_STR clob,
  STATIC FUNCTION ODCIAGGREGATEINITIALIZE(SCTX IN OUT type_concatenate)
    RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATEITERATE(SELF IN OUT type_concatenate,
                                       P1   IN VARCHAR2) RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATETERMINATE(SELF        IN type_concatenate,
                                         RETURNVALUE OUT clob,
                                         FLAGS       IN NUMBER)
    RETURN NUMBER,
  MEMBER FUNCTION ODCIAGGREGATEMERGE(SELF  IN OUT type_concatenate,
                                     SCTX2 IN type_concatenate)
    RETURN NUMBER
)
/

