create TYPE ty_str_split IS TABLE OF VARCHAR2 (4000)
/

