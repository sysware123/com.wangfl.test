create view P2M_TO_KE_DATA as
  SELECT d."TASKID",
       d."NAME",
       d."CODE",
       d."MODELID",
       phase.name phaseName,
       phase.enum_attribute_id phaseEnumId,
       specialty.name specialtyName,
       specialty.enum_attribute_id specialtyEnumId,
       0 securityvalue,
       t.securitydegreeid securityid
 FROM pm_data_object d
 INNER join pm_task_object t
  ON t.id=d.taskid
 left join pm_structure_relation  r ON d.id = r.childid
  left join pm_enumattribute phase
    on t.projectPhaseId = phase.enum_attribute_id
   and phase.code = 'Phase'
    left join pm_enumattribute specialty
    on t.discipline = specialty.enum_attribute_id
   and specialty.code = 'Specialty'
    WHERE t.statusid='completed' AND r.relationType ='StructureRelation'
/

