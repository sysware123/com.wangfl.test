create view P2M_TO_KE_ACTIVEMODEL as
  SELECT p.name           phaseName, --活动模板所属阶段名称--
       o.departmenttype phaseEnumId,--活动模板所阶段门ID--
       o.discipline     specialtyEnumId,--活动模板所属专业名称--
       pe.name          specialtyName,--活动模板所属专业ID--
       o.name           taskName,--活动模板名称--
       o.modelid        modelid,--活动模板类型--
       o.id             taskId,--活动模板ID--
       o.description    description
  FROM dm_dt_task_object o, PM_EnumAttribute p, PM_EnumAttribute pe
 WHERE o.departmenttype = p.enum_attribute_id
   and o.discipline = pe.enum_attribute_id
   and o.modelTypeId = 'taskModel'
   and o.statusid not in ('deleted', 'disable')
   AND o.id IN (select max(l.id) maxId
                  from dm_dt_version v, dm_dt_link l
                 where v.id = l.id
                 group by l.srclinkedid)
/

