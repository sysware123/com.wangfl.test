create view P2M_TO_KE_TASK as
  select t."ID",
       t."CODE",
       t."NAME",
       t."STATUSID",
       t."MODELID",
       t."DESCRIPTION",
       t."ACTUALENDTIME",
       r."PARENTID",
       parent.name parentname,
       project.name projectname,
       status.status_name statusname,
       phase.name phaseName,
       phase.enum_attribute_id phaseEnumId,
       specialty.name specialtyName,
       specialty.enum_attribute_id specialtyEnumId,
       ideTemplate.Template_Name engineerTemplateName,
       0 securityvalue,
       t.securitydegreeid securityid
  from pm_task_object t
 inner join pm_wbs_relation r
    on t.id = r.childid
  left join pm_task_object parent
    on parent.id = r.parentid
  left join pm_task_object project
    on t.projectid = project.id
  left join pm_task_status status
    on t.statusid = status.status_id
   and status.group_id = 'TaskStatus'
  left join pm_enumattribute phase
    on t.projectPhaseId = phase.enum_attribute_id
   and phase.code = 'Phase'
    left join pm_enumattribute specialty
    on t.discipline = specialty.enum_attribute_id
   and specialty.code = 'Specialty'
  left join ide_template ideTemplate
    on ideTemplate.TEMPLATE_ID = t.ENGINEERTEMPLATEID
    where t.statusid='completed' and t.MODELTYPEID = 'taskModel'
/

